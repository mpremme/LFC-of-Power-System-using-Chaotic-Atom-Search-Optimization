%--------------------------------------------------------------------------
% Developed in MATLAB R2011b
% W. Zhao, L. Wang and Z. Zhang, Atom search optimization and its 
% application to solve a hydrogeologic parameter estimation problem, 
% Knowledge-Based Systems,2019,163:283-304, https://doi.org/10.1016/j.knosys.2018.08.030.
%--------------------------------------------------------------------------
 
%------------------------- Improved Atom Search Optimization (IASO) Algorithm -------------------------%
% ASO is improved by Chaos mechanism and the improved versions are named as
% LM-CASO, SM-CASO, and TM-CASO. The software is developed by Andrew Xavier Raj Irudayaraj, 
% Noor Izzri Abdul Wahab, M. Premkumar, Mohd Amran Mohd Radzi, Nasri Bin Sulaiman, 
% Veerapandiyan Veerasamy, Rizwan A. Farade, and Mohammad Zohrul Islam.
% Please cite the following paper if you find the code is useful for your work. 
% Cite: Andrew Xavier Raj Irudayaraj et. al., "Renewable Sources-based Automatic Load Frequency Control 
% of Interconnected Systems using Chaotic Atom Search Optimization,"
% Applied Soft Computing, Volume 119, April 2022, 108574, DOI:
% 10.1016/j.asoc.2022.108574.
%------------------------------------------------------------------------------------------------------%
%% ----------------------- Chaotic Atom Search Optimization (CASO) Algorithm --------------------------%

function [Best_POS,Best_FIT,CG_curve]=CASO(NP,Max_IT,lb,ub,dim,fobj)
 
    for i=1:3
        ChaosVec(i,:)=chaos(Max_IT,i);
    end
    
    lb = ones(1,dim).*lb;	% Lower boundary
    ub = ones(1,dim).*ub;	% Upper boundary
    
    alpha=40;
    beta=0.2;
    
    CV=ChaosVec(1,:);
    
    %% %---------------------- Initialization by Chaos----------------------------%
    T_NP = NP*dim; 

    XC = chaos(T_NP+1,1);
    XC = XC(2:T_NP+1);
    XC= reshape(XC,NP,dim);

    X= repmat(lb,NP,1) +XC.*(repmat(ub,NP,1) - repmat(lb,NP,1)); 
    V= repmat(lb,NP,1) +XC.*(repmat(ub,NP,1) - repmat(lb,NP,1)); 
    %---------------------------------------------------------------------%
    %% ---------------Compute the Initial Fitness of Atoms-------------------------------%
	for i=1:NP
        Fitness(i)=fobj(X(i,:));
	end
    %------------------------------------------------------------------------------------%
    %%      
	CG_curve=zeros(Max_IT,1);
	[Max_Fitness,Index]=min(Fitness);
	CG_curve(1)=Fitness(Index);
	Best_POS=X(Index,:);

    It=1; 
    
	% Calculate acceleration.
	Atom_Acc=Acceleration_ch(X,Fitness,It,Max_IT,dim,NP,Best_POS,alpha,beta,CV);
    
    %% -------------------------------Main Loop----------------------------------%
 for It=2:Max_IT 
	
	for ZZ = 1:It
        CG_curve(It)=CG_curve(It-1);
        V=rand(NP,dim).*V+Atom_Acc;
        X=X+V;     
        %% -------------------Boundary Handling Mechanism--------------------------------%
        for i=1:NP
            % Relocate atom out of range.  
            T_ub= X(i,:)>ub;
            T_lb= X(i,:)<lb;
            X(i,:)=(X(i,:).*(~(T_ub+T_lb)))+((rand(1,dim).*(ub-lb)+lb).*(T_ub+T_lb));
            %Evaluate atom. 
            Fitness(i)=fobj(X(i,:));
        end  
        %--------------------------------------------------------------------------------%
        %% -----------------------Position Update using Chaos ---------------------------%
        [Max_Fitness,Index]=min(Fitness);      
     
        if Max_Fitness<CG_curve(It)
             CG_curve(It)=Max_Fitness;
             Best_POS=X(Index,:);
        else
            xx=CV(ZZ); 
            r=fix(xx*NP)+1;
            X(r,:)=Best_POS;
        end
%----------------------------------------------------------------------------------------%
        %% --------------------- Calculate Acceleration (Update by Chaos)-----------------%
        Atom_Acc=Acceleration_ch(X,Fitness,It,Max_IT,dim,NP,Best_POS,alpha,beta,CV);
	end
end
Best_FIT=CG_curve(It); 
end

function Potential=LJPotential(Atom1,Atom2,Iteration,Max_Iteration,s)
	
    %Calculate LJ-potential
    r=norm(Atom1-Atom2);  
    c=(1-(Iteration-1)/Max_Iteration).^3;  
    rsmin=1.1+0.1*sin(Iteration/Max_Iteration*pi/2);
    rsmax=1.24;

    if r/s<rsmin
        rs=rsmin;
    else
    if  r/s>rsmax
        rs=rsmax;  
    else
        rs=r/s;
    end
    end           
Potential=c*(12*(-rs)^(-13)-6*(-rs)^(-7)); 
end

function Acc=Acceleration_ch(Atom_Pop,Fitness,It,Max_IT,dim,NP,X_Best,alpha,beta,CV)

for ZZ = 1:It
    
  %Calculate mass 
  M=exp(-(Fitness-max(Fitness))./(max(Fitness)-min(Fitness)));
  M=M./sum(M);  
  G=exp(-20*It/Max_IT); 
  Kbest=NP-(NP-2)*(It/Max_IT)^0.5;
  Kbest=floor(Kbest)+1;
  [Des_M Index_M]=sort(M,'descend');
 
 for i=1:NP       
	E(i,:)=zeros(1,dim);   
    MK(1,:)=sum(Atom_Pop(Index_M(1:Kbest),:),1)/Kbest;
    Distance=norm(Atom_Pop(i,:)-MK(1,:));   
	
    for k=1:Kbest
        j=Index_M(k);       
        %Calculate LJ-potential
        Potential=LJPotential(Atom_Pop(i,:),Atom_Pop(j,:),It,Max_IT,Distance); 
        r=CV(ZZ);
        E(i,:)=E(i,:)+r*Potential*((Atom_Pop(j,:)-Atom_Pop(i,:))/(norm(Atom_Pop(i,:)-Atom_Pop(j,:))+eps));             
    end
        
    E(i,:)=alpha*E(i,:)+beta*(X_Best-Atom_Pop(i,:));
	
    %Calculate acceleration
	a(i,:)=E(i,:)./M(i); 
 end
end
Acc=a.*G;
end

function O=chaos(max_iter,index)
O=zeros(1,max_iter);
x(1)=0.7;
Value=1;

switch index

    case 1 % Logistic map
    a=4;
    for i=1:max_iter
        x(i+1)=a*x(i)*(1-x(i));
        G(i)=x(i)*Value;
    end
    
    case 2 % Sine map
    for i=1:max_iter
        x(i+1) = sin(pi*x(i));
        G(i)=(x(i))*Value;
    end
    
    case 3 % Tent map
    x(1)=0.6;
    for i=1:max_iter
        if x(i)<0.7
            x(i+1)=x(i)/0.7;
        end
        if x(i)>=0.7
            x(i+1)=(10/3)*(1-x(i));
        end
        G(i)=(x(i))*Value;
    end
    
end
O=G;
end