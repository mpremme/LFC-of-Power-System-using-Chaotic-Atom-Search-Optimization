%------------------------- Improved Atom Search Optimization (IASO) Algorithm -------------------------%
% ASO is improved by Chaos mechanism and the improved versions are named as
% LM-CASO, SM-CASO, and TM-CASO. The software is developed by Andrew Xavier Raj Irudayaraj, 
% Noor Izzri Abdul Wahab, M. Premkumar, Mohd Amran Mohd Radzi, Nasri Bin Sulaiman, 
% Veerapandiyan Veerasamy, Rizwan A. Farade, and Mohammad Zohrul Islam.
% Please cite the following paper if you find the code is useful for your work. 
% Cite: Andrew Xavier Raj Irudayaraj et. al., "Renewable Sources-based Automatic Load Frequency Control 
% of Interconnected Systems using Chaotic Atom Search Optimization,"
% Applied Soft Computing, Volume 119, April 2022, 108574, DOI:
% 10.1016/j.asoc.2022.108574.
%------------------------------------------------------------------------------------------------------%

function [lb,ub,dim,fobj] = Obj_Functions(F)
switch F   
    case 'F1'
        fobj = @F1;
        lb=[ -5   -5     0     -5     0        -5    -5     0      -5    0         -5   -5    0     -5    0  ];
        ub=[   5    5    0.99    5    0.99       5     5    0.99     5    0.99       5    5    0.99   5   0.99];
        dim=15;
end
end

function o = F1(X)
kp=X(1,1);
kd=X(1,2);
mu=X(1,3);
ki=X(1,4);
lam=X(1,5);
kp1=X(1,6);
kd1=X(1,7);
mu1=X(1,8);
ki1=X(1,9);
lam1=X(1,10);
kp2=X(1,11);
kd2=X(1,12);
mu2=X(1,13);
ki2=X(1,14);
lam2=X(1,15);

opt=simset('solver','ode45','SrcWorkspace','Current');
[tout,xout,yout]=sim('MULTISOURCE',[0 50],opt);
o=mean(e);
end

function o=Ufun(x,a,k,m)
o=k.*((x-a).^m).*(x>a)+k.*((-x-a).^m).*(x<(-a));
end