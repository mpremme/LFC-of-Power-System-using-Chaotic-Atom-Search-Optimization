%--------------------------------------------------------------------------
% Developed in MATLAB R2011b
% W. Zhao, L. Wang and Z. Zhang, Atom search optimization and its 
% application to solve a hydrogeologic parameter estimation problem, 
% Knowledge-Based Systems,2019,163:283-304, https://doi.org/10.1016/j.knosys.2018.08.030.
%--------------------------------------------------------------------------
 
%------------------------- Improved Atom Search Optimization (IASO) Algorithm -------------------------%
% ASO is improved by Chaos mechanism and the improved versions are named as
% LM-CASO, SM-CASO, and TM-CASO. The software is developed by Andrew Xavier Raj Irudayaraj, 
% Noor Izzri Abdul Wahab, Manoharan Premkumar, Mohd Amran Mohd Radzi, Nasri Bin Sulaiman, 
% Veerapandiyan Veerasamy, Rizwan A. Farade, and Mohammad Zohrul Islam.
% Please cite the following paper if you find the code is useful for your work. 
% Cite: Andrew Xavier Raj Irudayaraj et. al., "Renewable Sources-based Automatic Load Frequency Control 
% of Interconnected Systems using Chaotic Atom Search Optimization,"
% Applied Soft Computing, Volume 119, April 2022, 108574, DOI:
% 10.1016/j.asoc.2022.108574.
%------------------------------------------------------------------------------------------------------%

clc;
clear;
close all;

NP=5;      % Atom Numbers
Max_IT=5;   % Maximum Number of Iterations

Fun_Num='F1';
               
[lb,ub,dim,fobj]=Obj_Functions(Fun_Num);  % Call the Boundaries and Dimension for Benchmarks

N_Runs = 1; % Number of Runs

for i=1:N_Runs
[Best_POS,Best_FIT,CG_Curve]=CASO(NP,Max_IT,lb,ub,dim,fobj);
end

display(['The best fitness is: ', num2str(Best_FIT)]);     % Display the Best Fitness by CASO

subplot(1,1,1)
semilogy(CG_Curve,'Color','r','LineWidth',2.5)   % Convergence Curve Obtained by CASO
xlabel('Iterations');
ylabel('Fitness');