%------------------------- Improved Atom Search Optimization (IASO) Algorithm -------------------------%
% ASO is improved by Chaos mechanism and the improved versions are named as
% LM-CASO, SM-CASO, and TM-CASO. The software is developed by Andrew Xavier Raj Irudayaraj, 
% Noor Izzri Abdul Wahab, Manoharan Premkumar, Mohd Amran Mohd Radzi, Nasri Bin Sulaiman, 
% Veerapandiyan Veerasamy, Rizwan A. Farade1, and Mohammad Zohrul Islam.
% Please cite the following paper if you find the code is useful for your work. 
% Cite: Andrew Xavier Raj Irudayaraj et. al., "Renewable Sources-based Automatic Load Frequency Control 
% of Interconnected Systems using Chaotic Atom Search Optimization,"
% Applied Soft Computing, Volume 119, April 2022, 108574, DOI:
% 10.1016/j.asoc.2022.108574.
%------------------------------------------------------------------------------------------------------%

Procedure to run the code:

1. First, click the Run_Me file and set proper population size and maximum number of iteration
2. Enter number of runs 
3. Enter the objective function number to be minimized (1 to 6). Else you can replace with your own objective functions
4. ASO parameters must be tuned for your respective problem. In this paper, parameter are properly tuned and you can use the same 
5. Finally, the best solutions will be returned after terminating criteria
